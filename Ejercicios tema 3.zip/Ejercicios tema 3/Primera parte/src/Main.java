public class Main
   {
    public static void main(String[] args)
    {
        int resultado =0;
        resultado = suma( 10, 8,10);
        System.out.println(resultado);
    }
    public static int suma(int a, int b, int c)
    {
        return a+b+c;
    }
}