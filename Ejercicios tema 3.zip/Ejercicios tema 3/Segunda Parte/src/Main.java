public class Main
{
    public static void main(String[] args)
    {
        Coche miCoche= new Coche();
        miCoche.sumarPuerta();
        System.out.println(miCoche.numPuerta);
    }
        public static int sumaPuerta(int a, int b)
    {
        return a + b;
    }
     static class Coche
    {
        public int numPuerta = 1;
        public void sumarPuerta()
        {
            this.numPuerta++;
        }
    }
}

