public class Potat {
}
