class Main {
    public static void main(String[] args)
    {
        var numeroIf = 7 ;
        if (numeroIf == 0) {
            System.out.println("El número es neutro");
        } else if (numeroIf < 0) {
            System.out.println("El número es negativo");
        } else {
            System.out.println("El número es positivo");
        }
    }
}
