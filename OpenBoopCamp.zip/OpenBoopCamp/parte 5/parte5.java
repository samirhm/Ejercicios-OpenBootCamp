
class Main {
    public static void main(String[] args) {
        var estacion = "Otoño";
        switch (estacion) {
            case "Primavera":
                System.out.println("es Primavera");
                break;
            case "Verano":
                System.out.println("es Verano");
                break;
            case "Otoño":
                System.out.println("es Otoño");
                break;
            case "Invierno":
                System.out.println("es Invierno");
                break;
            default:
                System.out.println("Estación Equivocada");
        }
    }
}
