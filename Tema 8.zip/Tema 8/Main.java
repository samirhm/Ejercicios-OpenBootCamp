public class Main {

    public static void main (String[] args)
    {
        Persona persona = new Persona();
        System.out.println(" Su Edad es: " + persona.getEdad());
        System.out.println(" Su Nombre es: " + persona.getNombre());
        System.out.println(" Su Telefono es: " + persona.getTelefono());

    }
}
