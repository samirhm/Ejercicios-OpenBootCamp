
public class Persona {
    private int edad;
    private String nombre;
    private int telefono;

    // constructor sin parametros
    public Persona()
    {   this.edad = 20 ;
        this.nombre = "Alan";
        this.telefono = 3212;
    }
    // constructor con parametros
    public Persona (int edad, String nombre, int telefono)
    {
        this.edad = edad ;
        this.nombre = nombre;
        this.telefono = telefono;
    }
            // accesadores
    public int getEdad()
    {
        return edad;
    }
    public String getNombre()
    {
        return nombre;
    }
    public int getTelefono()
    {
        return telefono;
    }

}
